// Utility function to get ordinal suffix for a day
function getOrdinalSuffix(day) {
    if (day > 3 && day < 21) return 'th';
    switch (day % 10) {
        case 1: return 'st';
        case 2: return 'nd';
        case 3: return 'rd';
        default: return 'th';
    }
}

// Utility function to get the full month name
function getMonthName(monthIndex) {
    const monthNames = [
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'
    ];
    return monthNames[monthIndex];
}

// Event listener to show the timezone overlay
document.getElementById('world-map').addEventListener('mousemove', function (event) {
    const timezoneOverlay = document.getElementById('timezone-info');
    const bounds = this.getBoundingClientRect();
    const x = event.clientX - bounds.left;
    const timezoneOffset = Math.floor((x / bounds.width) * 24 - 12); // Estimate the time zone offset

    // Get the current UTC time
    const now = new Date();
    const utcTime = new Date(now.getTime() + now.getTimezoneOffset() * 60000);

    // Calculate local time using the timezone offset
    const localTime = new Date(utcTime.getTime() + timezoneOffset * 3600000);

    // Extract day, month, hours, and minutes
    const day = localTime.getDate();
    const dayWithSuffix = `${day}${getOrdinalSuffix(day)}`;
    const month = getMonthName(localTime.getMonth());
    const hours = localTime.getHours().toString().padStart(2, '0');
    const minutes = localTime.getMinutes().toString().padStart(2, '0');

    // Create formatted string DDth-Month // HH MM
    timezoneOverlay.innerHTML = `<span id="date-display">${dayWithSuffix} ${month}</span> // <span id="time-display" style="font-style: normal;">${hours} ${minutes}</span>`;

    // Display the calculated local time above the cursor position
    timezoneOverlay.style.display = 'block';
    timezoneOverlay.style.left = `${event.clientX - bounds.left}px`;
    timezoneOverlay.style.top = `${event.clientY - bounds.top - 30}px`; // Adjust to be just above the cursor
});

document.getElementById('world-map').addEventListener('mouseout', function () {
    const timezoneOverlay = document.getElementById('timezone-info');
    timezoneOverlay.style.display = 'none';
});